import tkinter as tk
from tkinter import messagebox, ttk
import mysql.connector
import os
from PIL import Image, ImageTk


janela_tkinter = tk.Tk()
janela_tkinter.title("Sistema de carrinho")
janela_tkinter.geometry("800x300")
janela_tkinter.resizable(False, False)


def buscardados():
    id_produto = campo_id.get()
    conn = mysql.connector.connect(
        host="localhost",
        port="3306",
        database="pythoncarrinho",
        user="root",
        password=""
    )
    cursor = conn.cursor()
    query = "SELECT idproduto, nome, foto, valor FROM produto WHERE idproduto = %s"
    cursor.execute(query, (id_produto,))
    row = cursor.fetchone()
    if row:
        limparocampo()
        codigo_produto, nome_produto, foto_produto, valor_produto = row
        campo_codigo.insert(tk.END, codigo_produto)
        campo_nome_produto.insert(tk.END, nome_produto)
        campo_valor.insert(tk.END, valor_produto)

        if foto_produto:
            imagem_path = os.path.join("C:\\xampp\\htdocs\\python\\pythontrabalho\\img", foto_produto)
            if os.path.exists(imagem_path):
                image = Image.open(imagem_path)
                image = image.resize((130, 130))
                photo = ImageTk.PhotoImage(image=image)
                label_foto.config(image=photo)
                label_foto.image = photo

    conn.close()


def total(event: object = None) -> object:
    try:
        quantidade = int(campo_qtd.get())
        valor = int(campo_valor.get())
        total = quantidade * valor
        campo_total.delete(0, tk.END)
        campo_total.insert(tk.END, total)
    except ValueError:
        messagebox.showerror("Erro", "Insira valores ")


def atualizarototal(event=None):
    try:
        quantidade = int(campo_qtd.get())
        valor = int(campo_valor.get())
        total = quantidade * valor
        campo_total.delete(0, tk.END)
        campo_total.insert(tk.END, total)
    except ValueError:
        pass


def limparocampo():
    campo_codigo.delete(0, tk.END)
    campo_nome_produto.delete(0, tk.END)
    campo_valor.delete(0, tk.END)
    campo_qtd.delete(0, tk.END)
    campo_total.delete(0, tk.END)
    atualizartabela()


def atualizartabela():
    for row in tree.get_children():
        tree.delete(row)
    conn = mysql.connector.connect(
        host="localhost",
        port="3306",
        database="pythoncarrinho",
        user="root",
        password=""
    )
    cursor = conn.cursor()
    cursor.execute("SELECT idcompra, qtd, valor, total FROM compra")
    rows = cursor.fetchall()
    total_geral = 0
    for row in rows:
        tree.insert("", "end", values=row + ("",))
        total_geral += int(row[3])
    conn.close()

    label_total_geral.config(text=f"Total Geral: {total_geral}")


def adicionarasacola():
    quantidade = campo_qtd.get()
    valor = campo_valor.get()
    total = campo_total.get()
    if quantidade.strip() != "":
        conn = mysql.connector.connect(
            host="localhost",
            port="3306",
            database="pythoncarrinho",
            user="root",
            password=""
        )
        cursor = conn.cursor()
        query = "INSERT INTO compra (qtd, valor, total) VALUES (%s, %s, %s)"
        cursor.execute(query, (quantidade, valor, total))
        conn.commit()
        conn.close()
        messagebox.showinfo("Sucesso", "Produto adicionado ao carrinho")
        atualizartabela()
    else:
        messagebox.showerror("Erro", "Quantidade não pode tá vazio")


def excluiritem():
    item_selecionado = tree.selection()
    if item_selecionado:
        item = tree.item(item_selecionado)
        id_compra = item['values'][0]
        conn = mysql.connector.connect(
            host="localhost",
            port="3306",
            database="pythoncarrinho",
            user="root",
            password=""
        )
        cursor = conn.cursor()
        cursor.execute("DELETE FROM compra WHERE idcompra = %s", (id_compra,))
        conn.commit()
        conn.close()
        atualizartabela()


label_total_geral = tk.Label(janela_tkinter, text="Total Geral: 0")
label_total_geral.grid(row=8, column=3, padx=4, pady=4, sticky="w")

label_id = tk.Label(janela_tkinter, text="Buscar")
label_id.grid(row=0, column=0, padx=4, pady=4)
campo_id = tk.Entry(janela_tkinter)
campo_id.grid(row=0, column=1, padx=4, pady=4)
botao_buscar = tk.Button(janela_tkinter, text="Buscar", command=buscardados)
botao_buscar.grid(row=0, column=2, padx=4, pady=4)

label_foto = tk.Label(janela_tkinter)
label_foto.grid(row=1, column=2, rowspan=5, padx=20, pady=4)

label_espaco = tk.Label(janela_tkinter, text="")
label_espaco.grid(row=1, column=0)

label_codigo = tk.Label(janela_tkinter, text="Código")
label_codigo.grid(row=2, column=0, padx=4, pady=4)
campo_codigo = tk.Entry(janela_tkinter)
campo_codigo.grid(row=2, column=1, padx=4, pady=4)

label_nome_produto = tk.Label(janela_tkinter, text="Nome do Produto")
label_nome_produto.grid(row=3, column=0, padx=4, pady=4)
campo_nome_produto = tk.Entry(janela_tkinter)
campo_nome_produto.grid(row=3, column=1, padx=4, pady=4)

label_qtd = tk.Label(janela_tkinter, text="Quantidade")
label_qtd.grid(row=4, column=0, padx=4, pady=4)
campo_qtd = tk.Entry(janela_tkinter)
campo_qtd.grid(row=4, column=1, padx=4, pady=4)
campo_qtd.bind("<KeyRelease>", atualizarototal)

label_valor = tk.Label(janela_tkinter, text="Valor")
label_valor.grid(row=5, column=0, padx=4, pady=4)
campo_valor = tk.Entry(janela_tkinter)
campo_valor.grid(row=5, column=1, padx=4, pady=4)

label_total = tk.Label(janela_tkinter, text="Total")
label_total.grid(row=6, column=0, padx=4, pady=4)
campo_total = tk.Entry(janela_tkinter)
campo_total.grid(row=6, column=1, padx=4, pady=4)

tree = ttk.Treeview(janela_tkinter, columns=("id", "qtd", "valor", "total"), show="headings")
tree.heading("id", text="ID")
tree.heading("qtd", text="Quantidade")
tree.heading("valor", text="Valor")
tree.heading("total", text="Total")

tree.column("id", width=50)
tree.column("qtd", width=100)
tree.column("valor", width=100)
tree.column("total", width=100)

tree.grid(row=0, column=3, rowspan=7, padx=4, pady=4, sticky="nsew")
atualizartabela()

botao_adicionar_sacola = tk.Button(janela_tkinter, text="Adicionar a Sacola", command=adicionarasacola)
botao_adicionar_sacola.grid(row=7, column=1, padx=4, pady=4)

botao_excluir = tk.Button(janela_tkinter, text="Excluir", command=excluiritem)
botao_excluir.grid(row=7, column=3, padx=4, pady=4)


janela_tkinter.mainloop()
