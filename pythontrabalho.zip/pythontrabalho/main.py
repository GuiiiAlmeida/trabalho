print('main')

