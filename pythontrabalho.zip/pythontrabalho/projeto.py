"""nome = input('Digite seu nome')
print()
snome = input('Digite seu sobrenome')
print()
idade = int(input('Digite sua idade:'))
print()

def menoroumaior(ida):
    if ida >= 18:
        print('Você é maior de idade')
    else:
        print('Você é menor de idade')
    return ida


print(menoroumaior(idade))
"""
"""nome = input('Digite seu nome')
print()
hora = int (input('Digite a hora'))
print()
if hora >= 12 and hora <= 18:
    print('Sr' + nome + 'Boa tarde!')
elif hora < 12 and hora > 6:
    print('Sr' + nome + 'Bom dia!')
else:
    print('Sr' + nome + 'Boa noite')"""

idade = int(input('Digite sua idade'))
print()
if idade > 18 and idade < 65:
    print('Você pode votar')
else:
    print('Não rsrsrsrs')

